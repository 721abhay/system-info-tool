# Tools Installation Script
# This script adds the tools directory to the system PATH and creates shortcuts

param(
    [switch]$SystemWide,
    [switch]$CreateShortcuts,
    [switch]$CreateAliases
)

# Get the current tools directory
$ToolsDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir = Resolve-Path $ToolsDir

Write-Host "Installing tools from: $ToolsDir" -ForegroundColor Green

# Function to add directory to PATH
function Add-ToPath {
    param(
        [string]$Directory,
        [bool]$SystemWide = $false
    )
    
    $target = if ($SystemWide) { "Machine" } else { "User" }
    $currentPath = [Environment]::GetEnvironmentVariable("PATH", $target)
    
    if ($currentPath -notlike "*$Directory*") {
        $newPath = "$currentPath;$Directory"
        [Environment]::SetEnvironmentVariable("PATH", $newPath, $target)
        Write-Host "Added $Directory to $target PATH" -ForegroundColor Green
        return $true
    } else {
        Write-Host "Directory $Directory already in $target PATH" -ForegroundColor Yellow
        return $false
    }
}

# Add tools directory to PATH
try {
    $pathAdded = Add-ToPath -Directory $ToolsDir -SystemWide $SystemWide
    
    if ($pathAdded) {
        Write-Host "Tools directory added to PATH successfully!" -ForegroundColor Green
        Write-Host "You may need to restart your terminal for changes to take effect." -ForegroundColor Yellow
    }
} catch {
    Write-Host "Error adding to PATH: $($_.Exception.Message)" -ForegroundColor Red
}

# Create PowerShell profile aliases
if ($CreateAliases) {
    Write-Host "Creating PowerShell aliases..." -ForegroundColor Green
    
    $profilePath = $PROFILE
    if (-not (Test-Path $profilePath)) {
        New-Item -ItemType File -Path $profilePath -Force | Out-Null
    }
    
    $aliasContent = @"

# System Information Tool Aliases
Set-Alias -Name sysinfo -Value '$ToolsDir\sysinfo.ps1'
Set-Alias -Name systeminfo -Value '$ToolsDir\sysinfo.ps1'
Set-Alias -Name hwinfo -Value '$ToolsDir\sysinfo.ps1'

# Quick access functions
function Get-SystemInfo { & '$ToolsDir\sysinfo.ps1' @args }
function Get-HardwareInfo { & '$ToolsDir\sysinfo.ps1' -Hardware @args }
function Get-NetworkInfo { & '$ToolsDir\sysinfo.ps1' -Network @args }
function Get-PerformanceInfo { & '$ToolsDir\sysinfo.ps1' -Performance @args }
function Get-DetailedSystemInfo { & '$ToolsDir\sysinfo.ps1' -All @args }

"@
    
    # Check if aliases already exist
    $profileContent = Get-Content $profilePath -ErrorAction SilentlyContinue
    if ($profileContent -notmatch "System Information Tool Aliases") {
        Add-Content -Path $profilePath -Value $aliasContent
        Write-Host "PowerShell aliases added to profile: $profilePath" -ForegroundColor Green
    } else {
        Write-Host "PowerShell aliases already exist in profile" -ForegroundColor Yellow
    }
}

# Create desktop shortcuts
if ($CreateShortcuts) {
    Write-Host "Creating desktop shortcuts..." -ForegroundColor Green
    
    $WshShell = New-Object -ComObject WScript.Shell
    $Desktop = [Environment]::GetFolderPath("Desktop")
    
    # System Info shortcut
    $Shortcut = $WshShell.CreateShortcut("$Desktop\System Information Tool.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$ToolsDir\sysinfo.ps1`""
    $Shortcut.WorkingDirectory = $ToolsDir
    $Shortcut.Description = "Comprehensive System Information Tool"
    $Shortcut.Save()
    
    # Hardware Info shortcut
    $Shortcut = $WshShell.CreateShortcut("$Desktop\Hardware Information.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$ToolsDir\sysinfo.ps1`" -Hardware"
    $Shortcut.WorkingDirectory = $ToolsDir
    $Shortcut.Description = "Hardware Information Tool"
    $Shortcut.Save()
    
    Write-Host "Desktop shortcuts created successfully!" -ForegroundColor Green
}

# Create Start Menu shortcuts
if ($CreateShortcuts) {
    Write-Host "Creating Start Menu shortcuts..." -ForegroundColor Green
    
    $StartMenu = [Environment]::GetFolderPath("Programs")
    $ToolsFolder = "$StartMenu\System Tools"
    
    if (-not (Test-Path $ToolsFolder)) {
        New-Item -ItemType Directory -Path $ToolsFolder -Force | Out-Null
    }
    
    # System Info Start Menu shortcut
    $Shortcut = $WshShell.CreateShortcut("$ToolsFolder\System Information Tool.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$ToolsDir\sysinfo.ps1`""
    $Shortcut.WorkingDirectory = $ToolsDir
    $Shortcut.Description = "Comprehensive System Information Tool"
    $Shortcut.Save()
    
    Write-Host "Start Menu shortcuts created successfully!" -ForegroundColor Green
}

Write-Host ""
Write-Host "Installation Summary:" -ForegroundColor Cyan
Write-Host "===================" -ForegroundColor Cyan
Write-Host "Tools Directory: $ToolsDir" -ForegroundColor White
Write-Host "Available Commands:" -ForegroundColor White
Write-Host "  sysinfo                    # Basic system information" -ForegroundColor Green
Write-Host "  sysinfo -All               # Complete system report" -ForegroundColor Green
Write-Host "  sysinfo -Hardware          # Hardware information" -ForegroundColor Green
Write-Host "  sysinfo -Performance       # Performance metrics" -ForegroundColor Green
Write-Host "  sysinfo -Network           # Network information" -ForegroundColor Green
Write-Host "  sysinfo -Security          # Security information" -ForegroundColor Green
Write-Host "  sysinfo -help              # Show all options" -ForegroundColor Green
Write-Host ""
Write-Host "Installation completed successfully!" -ForegroundColor Green
