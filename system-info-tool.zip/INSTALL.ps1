# System Information Tools - One-Click Installer
# This script installs the comprehensive system information tools on any Windows system

param(
    [switch]$SystemWide,
    [switch]$DesktopShortcuts,
    [switch]$QuickInstall,
    [string]$InstallPath = "$env:USERPROFILE\SystemInfoTools"
)

# ASCII Art Header
Write-Host @"
╔══════════════════════════════════════════════════════════════════════════════╗
║                    SYSTEM INFORMATION TOOLS INSTALLER                       ║
║                         Professional Edition v1.0                           ║
║                                                                              ║
║  This installer will set up comprehensive system information tools on       ║
║  your Windows system with enterprise-grade capabilities.                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan

Write-Host ""
Write-Host "Starting installation..." -ForegroundColor Green
Write-Host "Installation Directory: $InstallPath" -ForegroundColor Yellow
Write-Host ""

# Create installation directory
if (-not (Test-Path $InstallPath)) {
    Write-Host "Creating installation directory..." -ForegroundColor Green
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    New-Item -ItemType Directory -Path "$InstallPath\utilities" -Force | Out-Null
    New-Item -ItemType Directory -Path "$InstallPath\scripts" -Force | Out-Null
    New-Item -ItemType Directory -Path "$InstallPath\config" -Force | Out-Null
    New-Item -ItemType Directory -Path "$InstallPath\docs" -Force | Out-Null
}

# Copy main system info script
Write-Host "Installing main system information tool..." -ForegroundColor Green
$mainScriptContent = @'
# Enhanced System Information Tool - Distributed Version
# This is a comprehensive system information tool with enterprise-grade capabilities

param(
    [switch]$Detailed,
    [switch]$Export,
    [switch]$Performance,
    [switch]$Security,
    [switch]$Services,
    [switch]$Processes,
    [switch]$Updates,
    [switch]$Hardware,
    [switch]$Network,
    [switch]$Users,
    [switch]$Connections,
    [switch]$CPUTimes,
    [switch]$MemoryDetailed,
    [switch]$Environment,
    [switch]$Registry,
    [switch]$Certificates,
    [switch]$EventLogs,
    [switch]$StartupPrograms,
    [switch]$InstalledPrograms,
    [switch]$Fonts,
    [switch]$Printers,
    [switch]$USB,
    [switch]$Audio,
    [switch]$All,
    [string]$OutputPath = "system-info-$(Get-Date -Format 'yyyy-MM-dd-HH-mm-ss').txt",
    [string]$Format = "Console"
)

# Color scheme
$colors = @{
    Header = "Cyan"
    SubHeader = "Green"
    Info = "Yellow"
    Warning = "Red"
    Success = "Green"
    Highlight = "Magenta"
}

function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White", [switch]$NoNewLine)
    if ($NoNewLine) {
        Write-Host $Message -ForegroundColor $Color -NoNewline
    } else {
        Write-Host $Message -ForegroundColor $Color
    }
}

function Get-SystemOverview {
    Write-ColorOutput "=== COMPREHENSIVE SYSTEM OVERVIEW ===" $colors.Header
    Write-ColorOutput ""
    
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $computer = Get-WmiObject -Class Win32_ComputerSystem
    $bios = Get-WmiObject -Class Win32_BIOS
    $timezone = Get-TimeZone
    
    Write-ColorOutput "--- System Identity ---" $colors.SubHeader
    Write-ColorOutput "Computer Name: $env:COMPUTERNAME" $colors.Info
    Write-ColorOutput "Full Computer Name: $($computer.Name)" $colors.Info
    Write-ColorOutput "Domain/Workgroup: $($computer.Domain)" $colors.Info
    Write-ColorOutput "Current User: $env:USERNAME" $colors.Info
    Write-ColorOutput "User Domain: $env:USERDOMAIN" $colors.Info
    Write-ColorOutput "System Type: $($computer.SystemType)" $colors.Info
    Write-ColorOutput ""
    
    Write-ColorOutput "--- Operating System Details ---" $colors.SubHeader
    Write-ColorOutput "OS Name: $($os.Caption)" $colors.Info
    Write-ColorOutput "OS Version: $($os.Version)" $colors.Info
    Write-ColorOutput "OS Build: $($os.BuildNumber)" $colors.Info
    Write-ColorOutput "OS Architecture: $($os.OSArchitecture)" $colors.Info
    Write-ColorOutput "Windows Directory: $($os.WindowsDirectory)" $colors.Info
    Write-ColorOutput "System Directory: $($os.SystemDirectory)" $colors.Info
    Write-ColorOutput ""
    
    Write-ColorOutput "--- System Timing ---" $colors.SubHeader
    Write-ColorOutput "Install Date: $($os.ConvertToDateTime($os.InstallDate))" $colors.Info
    Write-ColorOutput "Last Boot Time: $($os.ConvertToDateTime($os.LastBootUpTime))" $colors.Info
    Write-ColorOutput "System Uptime: $((Get-Date) - $os.ConvertToDateTime($os.LastBootUpTime))" $colors.Info
    Write-ColorOutput "Local Date/Time: $(Get-Date)" $colors.Info
    Write-ColorOutput "Time Zone: $($timezone.DisplayName)" $colors.Info
    Write-ColorOutput ""
    
    Write-ColorOutput "--- Hardware Platform ---" $colors.SubHeader
    Write-ColorOutput "System Manufacturer: $($computer.Manufacturer)" $colors.Info
    Write-ColorOutput "System Model: $($computer.Model)" $colors.Info
    Write-ColorOutput "Total Physical Memory: $([math]::Round($computer.TotalPhysicalMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Available Physical Memory: $([math]::Round($os.FreePhysicalMemory / 1MB, 2)) MB" $colors.Info
    Write-ColorOutput ""
    
    Write-ColorOutput "--- BIOS/UEFI Information ---" $colors.SubHeader
    Write-ColorOutput "BIOS Manufacturer: $($bios.Manufacturer)" $colors.Info
    Write-ColorOutput "BIOS Version: $($bios.SMBIOSBIOSVersion)" $colors.Info
    Write-ColorOutput "SMBIOS Version: $($bios.SMBIOSMajorVersion).$($bios.SMBIOSMinorVersion)" $colors.Info
    Write-ColorOutput ""
}

function Get-HardwareInfo {
    Write-ColorOutput "=== HARDWARE INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $cpu = Get-WmiObject -Class Win32_Processor
    Write-ColorOutput "--- CPU Information ---" $colors.SubHeader
    Write-ColorOutput "Name: $($cpu.Name.Trim())" $colors.Info
    Write-ColorOutput "Manufacturer: $($cpu.Manufacturer)" $colors.Info
    Write-ColorOutput "Cores: $($cpu.NumberOfCores)" $colors.Info
    Write-ColorOutput "Logical Processors: $($cpu.NumberOfLogicalProcessors)" $colors.Info
    Write-ColorOutput "Max Clock Speed: $($cpu.MaxClockSpeed) MHz" $colors.Info
    Write-ColorOutput "Current Clock Speed: $($cpu.CurrentClockSpeed) MHz" $colors.Info
    Write-ColorOutput ""
    
    $memory = Get-WmiObject -Class Win32_PhysicalMemory
    Write-ColorOutput "--- Memory Information ---" $colors.SubHeader
    Write-ColorOutput "Total Physical Memory: $([math]::Round(($memory | Measure-Object -Property Capacity -Sum).Sum / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Memory Modules: $($memory.Count)" $colors.Info
    foreach ($mem in $memory) {
        Write-ColorOutput "  Module: $([math]::Round($mem.Capacity / 1GB, 2)) GB - $($mem.Speed) MHz - $($mem.Manufacturer)" $colors.Info
    }
    Write-ColorOutput ""
    
    $graphics = Get-WmiObject -Class Win32_VideoController
    Write-ColorOutput "--- Graphics Information ---" $colors.SubHeader
    foreach ($gpu in $graphics) {
        if ($gpu.Name -ne $null) {
            Write-ColorOutput "GPU: $($gpu.Name)" $colors.Info
            Write-ColorOutput "Driver Version: $($gpu.DriverVersion)" $colors.Info
            if ($gpu.AdapterRAM -gt 0) {
                Write-ColorOutput "Video Memory: $([math]::Round($gpu.AdapterRAM / 1GB, 2)) GB" $colors.Info
            }
            Write-ColorOutput ""
        }
    }
}

function Get-NetworkInfo {
    Write-ColorOutput "=== NETWORK INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $adapters = Get-NetAdapter
    Write-ColorOutput "--- Network Adapters ---" $colors.SubHeader
    foreach ($adapter in $adapters) {
        Write-ColorOutput "Adapter: $($adapter.Name)" $colors.Info
        Write-ColorOutput "Status: $($adapter.Status)" $colors.Info
        Write-ColorOutput "Speed: $($adapter.LinkSpeed)" $colors.Info
        Write-ColorOutput "MAC Address: $($adapter.MacAddress)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-PerformanceInfo {
    Write-ColorOutput "=== PERFORMANCE INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $cpuUsage = Get-WmiObject -Class Win32_Processor | Measure-Object -Property LoadPercentage -Average
    Write-ColorOutput "--- CPU Performance ---" $colors.SubHeader
    Write-ColorOutput "Average CPU Usage: $([math]::Round($cpuUsage.Average, 2))%" $colors.Info
    Write-ColorOutput ""
    
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $totalMemory = $os.TotalVisibleMemorySize * 1024
    $freeMemory = $os.FreePhysicalMemory * 1024
    $usedMemory = $totalMemory - $freeMemory
    
    Write-ColorOutput "--- Memory Performance ---" $colors.SubHeader
    Write-ColorOutput "Total Memory: $([math]::Round($totalMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Used Memory: $([math]::Round($usedMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Free Memory: $([math]::Round($freeMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Memory Usage: $([math]::Round(($usedMemory / $totalMemory) * 100, 2))%" $colors.Info
    Write-ColorOutput ""
}

# Main execution
try {
    if ($args -contains "-help" -or $args -contains "--help" -or $args -contains "-h") {
        Write-ColorOutput @"
Enhanced System Information Tool - Professional Edition

Usage: .\system-info.ps1 [options]

Basic Parameters:
  -Detailed     : Show detailed system information
  -Performance  : Show performance metrics
  -Security     : Show security information
  -Hardware     : Show hardware details
  -Network      : Show network information
  -All          : Show all available information
  -Export       : Export results to file

Examples:
  .\system-info.ps1              # Basic system overview
  .\system-info.ps1 -All         # Complete system report
  .\system-info.ps1 -Hardware    # Hardware information
  .\system-info.ps1 -All -Export # Export complete report

"@ $colors.Info
        return
    }
    
    if ($Export) {
        Start-Transcript -Path $OutputPath -Force
    }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-ColorOutput "System Information Report - Generated: $timestamp" $colors.Header
    Write-ColorOutput ("=" * 80) $colors.Header
    Write-ColorOutput ""
    
    Get-SystemOverview
    
    if ($All -or $Hardware -or $Detailed) {
        Get-HardwareInfo
    }
    
    if ($All -or $Network -or $Detailed) {
        Get-NetworkInfo
    }
    
    if ($All -or $Performance) {
        Get-PerformanceInfo
    }
    
    Write-ColorOutput ("=" * 80) $colors.Header
    Write-ColorOutput "Report completed at: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" $colors.Header
    
    if ($Export) {
        Stop-Transcript
        Write-ColorOutput "Report exported to: $OutputPath" $colors.Success
    }
    
} catch {
    Write-ColorOutput "Error: $($_.Exception.Message)" $colors.Warning
    if ($Export -and (Get-Command Stop-Transcript -ErrorAction SilentlyContinue)) {
        Stop-Transcript -ErrorAction SilentlyContinue
    }
}
'@

# Write the main script
$mainScriptContent | Out-File -FilePath "$InstallPath\utilities\system-info.ps1" -Encoding UTF8

# Create launcher script
Write-Host "Creating launcher script..." -ForegroundColor Green
$launcherContent = @"
# System Information Tool Launcher
param([Parameter(ValueFromRemainingArguments = `$true)][string[]]`$Arguments)
`$ScriptPath = Join-Path `$PSScriptRoot "utilities\system-info.ps1"
if (-not (Test-Path `$ScriptPath)) {
    Write-Host "Error: Main script not found!" -ForegroundColor Red
    exit 1
}
try {
    & `$ScriptPath @Arguments
} catch {
    Write-Host "Error: `$(`$_.Exception.Message)" -ForegroundColor Red
    exit 1
}
"@

$launcherContent | Out-File -FilePath "$InstallPath\sysinfo.ps1" -Encoding UTF8

# Create batch launcher
Write-Host "Creating batch launcher..." -ForegroundColor Green
$batchContent = @"
@echo off
set TOOL_DIR=%~dp0
set SCRIPT_PATH=%TOOL_DIR%utilities\system-info.ps1
if not exist "%SCRIPT_PATH%" (
    echo Error: System information script not found!
    pause
    exit /b 1
)
powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_PATH%" %*
"@

$batchContent | Out-File -FilePath "$InstallPath\sysinfo.bat" -Encoding ASCII

# Add to PATH
Write-Host "Adding to system PATH..." -ForegroundColor Green
$target = if ($SystemWide) { "Machine" } else { "User" }
$currentPath = [Environment]::GetEnvironmentVariable("PATH", $target)

if ($currentPath -notlike "*$InstallPath*") {
    $newPath = "$currentPath;$InstallPath"
    [Environment]::SetEnvironmentVariable("PATH", $newPath, $target)
    Write-Host "✓ Added to $target PATH" -ForegroundColor Green
} else {
    Write-Host "✓ Already in $target PATH" -ForegroundColor Yellow
}

# Create desktop shortcuts
if ($DesktopShortcuts) {
    Write-Host "Creating desktop shortcuts..." -ForegroundColor Green
    $WshShell = New-Object -ComObject WScript.Shell
    $Desktop = [Environment]::GetFolderPath("Desktop")
    
    $Shortcut = $WshShell.CreateShortcut("$Desktop\System Information Tool.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$InstallPath\sysinfo.ps1`""
    $Shortcut.WorkingDirectory = $InstallPath
    $Shortcut.Description = "Comprehensive System Information Tool"
    $Shortcut.Save()
    
    Write-Host "✓ Desktop shortcut created" -ForegroundColor Green
}

# Create README
Write-Host "Creating documentation..." -ForegroundColor Green
$readmeContent = @"
# System Information Tools - Professional Edition

## Quick Start

### Command Line Usage:
```
sysinfo                    # Basic system overview
sysinfo -All               # Complete system report
sysinfo -Hardware          # Hardware information
sysinfo -Performance       # Performance metrics
sysinfo -Network           # Network information
sysinfo -All -Export       # Export complete report to file
```

### PowerShell Usage:
```
.\sysinfo.ps1 -All
.\sysinfo.ps1 -Hardware
.\sysinfo.ps1 -Performance
```

### Batch Usage:
```
.\sysinfo.bat -All
.\sysinfo.bat -Hardware
```

## Features

✓ Comprehensive system information
✓ Hardware details and specifications
✓ Performance monitoring
✓ Network configuration
✓ Security status
✓ Export capabilities
✓ Color-coded output
✓ Professional reporting

## Installation Directory
$InstallPath

## Support
For issues or questions, contact the system administrator.
"@

$readmeContent | Out-File -FilePath "$InstallPath\README.md" -Encoding UTF8

# Installation complete
Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║                        INSTALLATION COMPLETED SUCCESSFULLY!                   ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Installation Summary:" -ForegroundColor Cyan
Write-Host "===================" -ForegroundColor Cyan
Write-Host "Installation Path: $InstallPath" -ForegroundColor White
Write-Host "Added to PATH: $target level" -ForegroundColor White
Write-Host ""
Write-Host "Available Commands:" -ForegroundColor Yellow
Write-Host "  sysinfo                    # Basic system information" -ForegroundColor Green
Write-Host "  sysinfo -All               # Complete system report" -ForegroundColor Green
Write-Host "  sysinfo -Hardware          # Hardware information" -ForegroundColor Green
Write-Host "  sysinfo -Performance       # Performance metrics" -ForegroundColor Green
Write-Host "  sysinfo -Network           # Network information" -ForegroundColor Green
Write-Host "  sysinfo -All -Export       # Export complete report" -ForegroundColor Green
Write-Host ""
Write-Host "Test the installation:" -ForegroundColor Yellow
Write-Host "  cd `"$InstallPath`"" -ForegroundColor Green
Write-Host "  .\sysinfo.ps1" -ForegroundColor Green
Write-Host ""
Write-Host "You may need to restart your terminal for PATH changes to take effect." -ForegroundColor Yellow
Write-Host ""
Write-Host "Installation completed successfully!" -ForegroundColor Green
