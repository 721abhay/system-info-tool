# Utilities Directory

This directory contains standalone utility programs and helper tools.

## Categories

- **file-tools/**: File manipulation and processing utilities
- **network/**: Network-related utilities
- **system/**: System administration utilities
- **dev-tools/**: Development helper tools

## Usage

Each utility should include:
- Clear documentation
- Usage examples
- Dependencies list
- Installation instructions (if applicable)

## Example Structure

```
utilities/
├── file-tools/
│   ├── bulk-rename.ps1
│   └── file-organizer.py
├── network/
│   ├── port-scanner.py
│   └── network-info.ps1
└── system/
    ├── cleanup.ps1
    └── system-info.ps1
```
