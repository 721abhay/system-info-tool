# Scripts Directory

This directory contains automation scripts and build tools.

## Categories

- **build/**: Build and compilation scripts
- **deploy/**: Deployment automation
- **maintenance/**: System maintenance scripts
- **setup/**: Environment setup scripts

## Usage

Make sure scripts are executable before running:
```powershell
# For PowerShell scripts
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Run a script
.\script-name.ps1
```

## Best Practices

1. Include help documentation in each script
2. Use proper error handling
3. Test scripts thoroughly
4. Include dependencies and requirements
