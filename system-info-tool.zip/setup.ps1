# Quick Setup Script for System Information Tools
# This script provides immediate access to the system information tools

Write-Host "System Information Tools - Quick Setup" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host ""

# Get the current directory
$ToolsDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir = Resolve-Path $ToolsDir

Write-Host "Tools Directory: $ToolsDir" -ForegroundColor Green
Write-Host ""

# Test if the main script exists
$MainScript = Join-Path $ToolsDir "utilities\system-info.ps1"
if (Test-Path $MainScript) {
    Write-Host "✓ Main system information script found" -ForegroundColor Green
} else {
    Write-Host "✗ Main system information script not found" -ForegroundColor Red
    exit 1
}

# Test if launcher scripts exist
$BatchLauncher = Join-Path $ToolsDir "sysinfo.bat"
$PowerShellLauncher = Join-Path $ToolsDir "sysinfo.ps1"

if (Test-Path $BatchLauncher) {
    Write-Host "✓ Batch launcher found" -ForegroundColor Green
} else {
    Write-Host "✗ Batch launcher not found" -ForegroundColor Red
}

if (Test-Path $PowerShellLauncher) {
    Write-Host "✓ PowerShell launcher found" -ForegroundColor Green
} else {
    Write-Host "✗ PowerShell launcher not found" -ForegroundColor Red
}

Write-Host ""
Write-Host "Available Access Methods:" -ForegroundColor Yellow
Write-Host "========================" -ForegroundColor Yellow
Write-Host ""

Write-Host "1. Direct Access (from current directory):" -ForegroundColor White
Write-Host "   .\sysinfo.ps1" -ForegroundColor Green
Write-Host "   .\sysinfo.bat" -ForegroundColor Green
Write-Host "   .\utilities\system-info.ps1" -ForegroundColor Green
Write-Host ""

Write-Host "2. Full Path Access (from anywhere):" -ForegroundColor White
Write-Host "   powershell -ExecutionPolicy Bypass -File '$PowerShellLauncher'" -ForegroundColor Green
Write-Host "   '$BatchLauncher'" -ForegroundColor Green
Write-Host ""

Write-Host "3. Quick Test Commands:" -ForegroundColor White
Write-Host "   # Basic system info" -ForegroundColor Gray
Write-Host "   .\sysinfo.ps1" -ForegroundColor Green
Write-Host "   # Hardware details" -ForegroundColor Gray
Write-Host "   .\sysinfo.ps1 -Hardware" -ForegroundColor Green
Write-Host "   # Complete report" -ForegroundColor Gray
Write-Host "   .\sysinfo.ps1 -All" -ForegroundColor Green
Write-Host "   # Export to file" -ForegroundColor Gray
Write-Host "   .\sysinfo.ps1 -All -Export" -ForegroundColor Green
Write-Host ""

Write-Host "4. Installation Options:" -ForegroundColor White
Write-Host "   # Add to PATH (user level)" -ForegroundColor Gray
Write-Host "   .\install-tools.ps1" -ForegroundColor Green
Write-Host "   # Add to PATH system-wide (requires admin)" -ForegroundColor Gray
Write-Host "   .\install-tools.ps1 -SystemWide" -ForegroundColor Green
Write-Host "   # Create shortcuts and aliases" -ForegroundColor Gray
Write-Host "   .\install-tools.ps1 -CreateShortcuts -CreateAliases" -ForegroundColor Green
Write-Host ""

Write-Host "5. Test the tool right now:" -ForegroundColor White
$response = Read-Host "Would you like to run a quick test? (y/n)"
if ($response -eq 'y' -or $response -eq 'Y') {
    Write-Host ""
    Write-Host "Running system information tool..." -ForegroundColor Green
    Write-Host ""
    & $MainScript
}

Write-Host ""
Write-Host "Setup information displayed successfully!" -ForegroundColor Green
Write-Host "You can now use the system information tools!" -ForegroundColor Green
