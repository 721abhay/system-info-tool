# Enhanced System Information Tool
# Description: Displays comprehensive system information with advanced features
# Usage: .\system-info.ps1 [options]

param(
    [switch]$Detailed,
    [switch]$Export,
    [switch]$Performance,
    [switch]$Security,
    [switch]$Services,
    [switch]$Processes,
    [switch]$Updates,
    [switch]$Hardware,
    [switch]$Network,
    [switch]$Users,
    [switch]$Connections,
    [switch]$CPUTimes,
    [switch]$MemoryDetailed,
    [switch]$Environment,
    [switch]$Registry,
    [switch]$Certificates,
    [switch]$EventLogs,
    [switch]$StartupPrograms,
    [switch]$InstalledPrograms,
    [switch]$Fonts,
    [switch]$Printers,
    [switch]$USB,
    [switch]$Audio,
    [switch]$All,
    [string]$OutputPath = "system-info-$(Get-Date -Format 'yyyy-MM-dd-HH-mm-ss').txt",
    [string]$Format = "Console" # Console, JSON, CSV, HTML
)

# Color scheme for output
$colors = @{
    Header = "Cyan"
    SubHeader = "Green"
    Info = "Yellow"
    Warning = "Red"
    Success = "Green"
    Highlight = "Magenta"
}

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White",
        [switch]$NoNewLine
    )
    if ($NoNewLine) {
        Write-Host $Message -ForegroundColor $Color -NoNewline
    } else {
        Write-Host $Message -ForegroundColor $Color
    }
}

function Get-AdvancedCPUTimes {
    Write-ColorOutput "=== CPU TIMES ===" $colors.Header
    Write-ColorOutput ""
    $cpuTimes = (Get-WmiObject -Class Win32_PerfFormattedData_Counters_ProcessorInformation | Where-Object {$_.Name -eq '_Total'})
    Write-ColorOutput "Processor Time: $($cpuTimes.PercentProcessorTime)%" $colors.Info
    Write-ColorOutput "User Time: $($cpuTimes.PercentUserTime)%" $colors.Info
    Write-ColorOutput "Privileged Time: $($cpuTimes.PercentPrivilegedTime)%" $colors.Info
    Write-ColorOutput "Idle Time: $([math]::Round(($cpuTimes.PercentIdleTime), 2))%" $colors.Info
    Write-ColorOutput "DPC Time: $([math]::Round(($cpuTimes.PercentDPCTime), 2))%" $colors.Info
    Write-ColorOutput "Interrupt Time: $([math]::Round(($cpuTimes.PercentInterruptTime), 2))%" $colors.Info
    Write-ColorOutput ""
}

function Get-AdvancedMemoryDetails {
    Write-ColorOutput "=== ADVANCED MEMORY INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    $memory = Get-CimInstance -ClassName Win32_OperatingSystem
    Write-ColorOutput "Total Visible Memory: $([math]::Round($memory.TotalVisibleMemorySize/1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Free Physical Memory: $([math]::Round($memory.FreePhysicalMemory/1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Total Virtual Memory: $([math]::Round($memory.TotalVirtualMemorySize/1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Free Virtual Memory: $([math]::Round($memory.FreeVirtualMemory/1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Page File Size: $([math]::Round($memory.SizeStoredInPagingFiles/1MB, 2)) MB" $colors.Info
    Write-ColorOutput ""
}

function Get-SystemOverview {
    Write-ColorOutput "=== DETAILED SYSTEM OVERVIEW ===" $colors.Header
    Write-ColorOutput ""
    
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $computer = Get-WmiObject -Class Win32_ComputerSystem
    $bios = Get-WmiObject -Class Win32_BIOS
    $processor = Get-WmiObject -Class Win32_Processor
    $timezone = Get-TimeZone
    
    # System Identity
    Write-ColorOutput "--- System Identity ---" $colors.SubHeader
    Write-ColorOutput "Computer Name: $env:COMPUTERNAME" $colors.Info
    Write-ColorOutput "Full Computer Name: $($computer.Name)" $colors.Info
    Write-ColorOutput "Domain/Workgroup: $($computer.Domain)" $colors.Info
    Write-ColorOutput "Part of Domain: $($computer.PartOfDomain)" $colors.Info
    Write-ColorOutput "Current User: $env:USERNAME" $colors.Info
    Write-ColorOutput "User Domain: $env:USERDOMAIN" $colors.Info
    Write-ColorOutput "System Type: $($computer.SystemType)" $colors.Info
    Write-ColorOutput "PC System Type: $($computer.PCSystemType)" $colors.Info
    Write-ColorOutput ""
    
    # Operating System Details
    Write-ColorOutput "--- Operating System Details ---" $colors.SubHeader
    Write-ColorOutput "OS Name: $($os.Caption)" $colors.Info
    Write-ColorOutput "OS Version: $($os.Version)" $colors.Info
    Write-ColorOutput "OS Build: $($os.BuildNumber)" $colors.Info
    Write-ColorOutput "OS Architecture: $($os.OSArchitecture)" $colors.Info
    Write-ColorOutput "OS Language: $($os.OSLanguage)" $colors.Info
    Write-ColorOutput "OS Product Type: $($os.ProductType)" $colors.Info
    Write-ColorOutput "OS Suite Mask: $($os.SuiteMask)" $colors.Info
    Write-ColorOutput "Service Pack: $($os.ServicePackMajorVersion).$($os.ServicePackMinorVersion)" $colors.Info
    Write-ColorOutput "Windows Directory: $($os.WindowsDirectory)" $colors.Info
    Write-ColorOutput "System Directory: $($os.SystemDirectory)" $colors.Info
    Write-ColorOutput "Boot Device: $($os.BootDevice)" $colors.Info
    Write-ColorOutput "System Device: $($os.SystemDevice)" $colors.Info
    Write-ColorOutput ""
    
    # System Timing
    Write-ColorOutput "--- System Timing ---" $colors.SubHeader
    Write-ColorOutput "Install Date: $($os.ConvertToDateTime($os.InstallDate))" $colors.Info
    Write-ColorOutput "Last Boot Time: $($os.ConvertToDateTime($os.LastBootUpTime))" $colors.Info
    Write-ColorOutput "System Uptime: $((Get-Date) - $os.ConvertToDateTime($os.LastBootUpTime))" $colors.Info
    Write-ColorOutput "Local Date/Time: $(Get-Date)" $colors.Info
    Write-ColorOutput "Time Zone: $($timezone.DisplayName)" $colors.Info
    Write-ColorOutput "Time Zone ID: $($timezone.Id)" $colors.Info
    Write-ColorOutput "UTC Offset: $($timezone.BaseUtcOffset)" $colors.Info
    Write-ColorOutput "Daylight Saving: $($timezone.SupportsDaylightSavingTime)" $colors.Info
    Write-ColorOutput ""
    
    # Hardware Platform
    Write-ColorOutput "--- Hardware Platform ---" $colors.SubHeader
    Write-ColorOutput "System Manufacturer: $($computer.Manufacturer)" $colors.Info
    Write-ColorOutput "System Model: $($computer.Model)" $colors.Info
    Write-ColorOutput "System Family: $($computer.SystemFamily)" $colors.Info
    Write-ColorOutput "System SKU: $($computer.SystemSKUNumber)" $colors.Info
    Write-ColorOutput "Chassis Type: $($computer.ChassisType)" $colors.Info
    Write-ColorOutput "Total Physical Memory: $([math]::Round($computer.TotalPhysicalMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Available Physical Memory: $([math]::Round($os.FreePhysicalMemory / 1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Virtual Memory Max: $([math]::Round($os.TotalVirtualMemorySize / 1MB, 2)) MB" $colors.Info
    Write-ColorOutput "Virtual Memory Available: $([math]::Round($os.FreeVirtualMemory / 1MB, 2)) MB" $colors.Info
    Write-ColorOutput ""
    
    # BIOS Information
    Write-ColorOutput "--- BIOS/UEFI Information ---" $colors.SubHeader
    Write-ColorOutput "BIOS Manufacturer: $($bios.Manufacturer)" $colors.Info
    Write-ColorOutput "BIOS Version: $($bios.SMBIOSBIOSVersion)" $colors.Info
    Write-ColorOutput "BIOS Release Date: $($bios.ReleaseDate)" $colors.Info
    Write-ColorOutput "SMBIOS Version: $($bios.SMBIOSMajorVersion).$($bios.SMBIOSMinorVersion)" $colors.Info
    Write-ColorOutput "BIOS Characteristics: $($bios.BiosCharacteristics)" $colors.Info
    Write-ColorOutput "Current Language: $($bios.CurrentLanguage)" $colors.Info
    Write-ColorOutput "Installable Languages: $($bios.InstallableLanguages)" $colors.Info
    Write-ColorOutput ""
    
    # Power Management
    Write-ColorOutput "--- Power Management ---" $colors.SubHeader
    Write-ColorOutput "Power Management Supported: $($computer.PowerManagementSupported)" $colors.Info
    Write-ColorOutput "Power Supply State: $($computer.PowerSupplyState)" $colors.Info
    Write-ColorOutput "Power State: $($computer.PowerState)" $colors.Info
    Write-ColorOutput "Reset Capability: $($computer.ResetCapability)" $colors.Info
    Write-ColorOutput "Wakeup Type: $($computer.WakeUpType)" $colors.Info
    Write-ColorOutput ""
}

function Get-HardwareInfo {
    Write-ColorOutput "=== COMPREHENSIVE HARDWARE INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # CPU Information
    Write-ColorOutput "--- Detailed CPU Information ---" $colors.SubHeader
    $cpu = Get-WmiObject -Class Win32_Processor
    Write-ColorOutput "Name: $($cpu.Name.Trim())" $colors.Info
    Write-ColorOutput "Manufacturer: $($cpu.Manufacturer)" $colors.Info
    Write-ColorOutput "Family: $($cpu.Family)" $colors.Info
    Write-ColorOutput "Model: $($cpu.Model)" $colors.Info
    Write-ColorOutput "Stepping: $($cpu.Stepping)" $colors.Info
    Write-ColorOutput "Architecture: $($cpu.Architecture)" $colors.Info
    Write-ColorOutput "Level: $($cpu.Level)" $colors.Info
    Write-ColorOutput "Revision: $($cpu.Revision)" $colors.Info
    Write-ColorOutput "Cores: $($cpu.NumberOfCores)" $colors.Info
    Write-ColorOutput "Logical Processors: $($cpu.NumberOfLogicalProcessors)" $colors.Info
    Write-ColorOutput "Max Clock Speed: $($cpu.MaxClockSpeed) MHz" $colors.Info
    Write-ColorOutput "Current Clock Speed: $($cpu.CurrentClockSpeed) MHz" $colors.Info
    Write-ColorOutput "External Clock: $($cpu.ExtClock) MHz" $colors.Info
    Write-ColorOutput "L2 Cache: $($cpu.L2CacheSize) KB" $colors.Info
    Write-ColorOutput "L3 Cache: $($cpu.L3CacheSize) KB" $colors.Info
    Write-ColorOutput "Cache Speed: $($cpu.L2CacheSpeed) MHz" $colors.Info
    Write-ColorOutput "Processor ID: $($cpu.ProcessorId)" $colors.Info
    Write-ColorOutput "Socket Designation: $($cpu.SocketDesignation)" $colors.Info
    Write-ColorOutput "Voltage: $($cpu.CurrentVoltage) V" $colors.Info
    Write-ColorOutput "Address Width: $($cpu.AddressWidth) bits" $colors.Info
    Write-ColorOutput "Data Width: $($cpu.DataWidth) bits" $colors.Info
    Write-ColorOutput "Load Percentage: $($cpu.LoadPercentage)%" $colors.Info
    Write-ColorOutput ""
    
    # Memory Information
    Write-ColorOutput "--- Detailed Memory Information ---" $colors.SubHeader
    $memory = Get-WmiObject -Class Win32_PhysicalMemory
    $totalMemory = ($memory | Measure-Object -Property Capacity -Sum).Sum
    Write-ColorOutput "Total Physical Memory: $([math]::Round($totalMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Memory Modules: $($memory.Count)" $colors.Info
    
    $slotNum = 1
    foreach ($mem in $memory) {
        Write-ColorOutput "  --- Memory Slot $slotNum ---" $colors.Highlight
        Write-ColorOutput "  Capacity: $([math]::Round($mem.Capacity / 1GB, 2)) GB" $colors.Info
        Write-ColorOutput "  Speed: $($mem.Speed) MHz" $colors.Info
        Write-ColorOutput "  Manufacturer: $($mem.Manufacturer)" $colors.Info
        Write-ColorOutput "  Part Number: $($mem.PartNumber)" $colors.Info
        Write-ColorOutput "  Serial Number: $($mem.SerialNumber)" $colors.Info
        Write-ColorOutput "  Device Locator: $($mem.DeviceLocator)" $colors.Info
        Write-ColorOutput "  Bank Label: $($mem.BankLabel)" $colors.Info
        Write-ColorOutput "  Memory Type: $($mem.MemoryType)" $colors.Info
        Write-ColorOutput "  Form Factor: $($mem.FormFactor)" $colors.Info
        Write-ColorOutput "  Data Width: $($mem.DataWidth) bits" $colors.Info
        Write-ColorOutput "  Total Width: $($mem.TotalWidth) bits" $colors.Info
        Write-ColorOutput "  Configured Clock Speed: $($mem.ConfiguredClockSpeed) MHz" $colors.Info
        Write-ColorOutput "  Voltage: $($mem.ConfiguredVoltage) V" $colors.Info
        Write-ColorOutput ""  $colors.Info
        $slotNum++
    }
    
    # Memory Usage
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $usedMemory = $totalMemory - ($os.FreePhysicalMemory * 1024)
    Write-ColorOutput "Current Memory Usage: $([math]::Round($usedMemory / 1GB, 2)) GB / $([math]::Round($totalMemory / 1GB, 2)) GB ($([math]::Round(($usedMemory / $totalMemory) * 100, 2))%)" $colors.Info
    Write-ColorOutput ""
    
    # Graphics Information
    Write-ColorOutput "--- Detailed Graphics Information ---" $colors.SubHeader
    $graphics = Get-WmiObject -Class Win32_VideoController
    $gpuNum = 1
    foreach ($gpu in $graphics) {
        if ($gpu.Name -ne $null) {
            Write-ColorOutput "  --- GPU $gpuNum ---" $colors.Highlight
            Write-ColorOutput "  Name: $($gpu.Name)" $colors.Info
            Write-ColorOutput "  Adapter Type: $($gpu.AdapterCompatibility)" $colors.Info
            Write-ColorOutput "  Processor: $($gpu.VideoProcessor)" $colors.Info
            Write-ColorOutput "  Driver Version: $($gpu.DriverVersion)" $colors.Info
            Write-ColorOutput "  Driver Date: $($gpu.DriverDate)" $colors.Info
            Write-ColorOutput "  INF Filename: $($gpu.InfFilename)" $colors.Info
            Write-ColorOutput "  INF Section: $($gpu.InfSection)" $colors.Info
            Write-ColorOutput "  Device ID: $($gpu.DeviceID)" $colors.Info
            Write-ColorOutput "  Status: $($gpu.Status)" $colors.Info
            Write-ColorOutput "  Availability: $($gpu.Availability)" $colors.Info
            if ($gpu.AdapterRAM -gt 0) {
                Write-ColorOutput "  Video Memory: $([math]::Round($gpu.AdapterRAM / 1GB, 2)) GB" $colors.Info
            }
            Write-ColorOutput "  Current Resolution: $($gpu.CurrentHorizontalResolution) x $($gpu.CurrentVerticalResolution)" $colors.Info
            Write-ColorOutput "  Current Refresh Rate: $($gpu.CurrentRefreshRate) Hz" $colors.Info
            Write-ColorOutput "  Min Refresh Rate: $($gpu.MinRefreshRate) Hz" $colors.Info
            Write-ColorOutput "  Max Refresh Rate: $($gpu.MaxRefreshRate) Hz" $colors.Info
            Write-ColorOutput "  Color Depth: $($gpu.CurrentBitsPerPixel) bits" $colors.Info
            Write-ColorOutput "  Video Architecture: $($gpu.VideoArchitecture)" $colors.Info
            Write-ColorOutput "  Video Memory Type: $($gpu.VideoMemoryType)" $colors.Info
            Write-ColorOutput ""  $colors.Info
            $gpuNum++
        }
    }
    
    # Motherboard Information
    Write-ColorOutput "--- Detailed Motherboard Information ---" $colors.SubHeader
    $motherboard = Get-WmiObject -Class Win32_BaseBoard
    Write-ColorOutput "Manufacturer: $($motherboard.Manufacturer)" $colors.Info
    Write-ColorOutput "Product: $($motherboard.Product)" $colors.Info
    Write-ColorOutput "Version: $($motherboard.Version)" $colors.Info
    Write-ColorOutput "Serial Number: $($motherboard.SerialNumber)" $colors.Info
    Write-ColorOutput "Tag: $($motherboard.Tag)" $colors.Info
    Write-ColorOutput "Configuration Options: $($motherboard.ConfigOptions)" $colors.Info
    Write-ColorOutput "Hosting Board: $($motherboard.HostingBoard)" $colors.Info
    Write-ColorOutput "Hot Swappable: $($motherboard.HotSwappable)" $colors.Info
    Write-ColorOutput "Removable: $($motherboard.Removable)" $colors.Info
    Write-ColorOutput "Replaceable: $($motherboard.Replaceable)" $colors.Info
    Write-ColorOutput "Requirements Description: $($motherboard.RequirementsDescription)" $colors.Info
    Write-ColorOutput "Slot Layout: $($motherboard.SlotLayout)" $colors.Info
    Write-ColorOutput ""
    
    # Additional Hardware Components
    Write-ColorOutput "--- System Slots ---" $colors.SubHeader
    $slots = Get-WmiObject -Class Win32_SystemSlot
    foreach ($slot in $slots) {
        Write-ColorOutput "Slot: $($slot.SlotDesignation) - Type: $($slot.SlotType) - Usage: $($slot.CurrentUsage)" $colors.Info
    }
    Write-ColorOutput ""
    
    # Ports
    Write-ColorOutput "--- System Ports ---" $colors.SubHeader
    $ports = Get-WmiObject -Class Win32_PortResource
    foreach ($port in $ports | Select-Object -First 10) {
        Write-ColorOutput "Port: $($port.Name) - Range: $($port.StartingAddress) - $($port.EndingAddress)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-StorageInfo {
    Write-ColorOutput "=== STORAGE INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # Physical Disks
    Write-ColorOutput "--- Physical Disks ---" $colors.SubHeader
    $physicalDisks = Get-WmiObject -Class Win32_DiskDrive
    foreach ($disk in $physicalDisks) {
        Write-ColorOutput "Disk: $($disk.Model)" $colors.Info
        Write-ColorOutput "Size: $([math]::Round($disk.Size / 1GB, 2)) GB" $colors.Info
        Write-ColorOutput "Interface: $($disk.InterfaceType)" $colors.Info
        Write-ColorOutput "Serial: $($disk.SerialNumber)" $colors.Info
        Write-ColorOutput ""
    }
    
    # Logical Drives
    Write-ColorOutput "--- Logical Drives ---" $colors.SubHeader
    $logicalDisks = Get-WmiObject -Class Win32_LogicalDisk
    foreach ($disk in $logicalDisks) {
        $freeSpace = [math]::Round($disk.FreeSpace / 1GB, 2)
        $totalSpace = [math]::Round($disk.Size / 1GB, 2)
        $usedPercent = if ($disk.Size -gt 0) { [math]::Round((($disk.Size - $disk.FreeSpace) / $disk.Size) * 100, 2) } else { 0 }
        
        Write-ColorOutput "Drive: $($disk.DeviceID)" $colors.Info
        Write-ColorOutput "Type: $($disk.DriveType)" $colors.Info
        Write-ColorOutput "File System: $($disk.FileSystem)" $colors.Info
        Write-ColorOutput "Total: $totalSpace GB" $colors.Info
        Write-ColorOutput "Free: $freeSpace GB" $colors.Info
        Write-ColorOutput "Used: $usedPercent%" $colors.Info
        Write-ColorOutput "Volume Label: $($disk.VolumeName)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-NetworkInfo {
    Write-ColorOutput "=== NETWORK INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # Network Adapters
    Write-ColorOutput "--- Network Adapters ---" $colors.SubHeader
    $adapters = Get-NetAdapter
    foreach ($adapter in $adapters) {
        Write-ColorOutput "Adapter: $($adapter.Name)" $colors.Info
        Write-ColorOutput "Status: $($adapter.Status)" $colors.Info
        Write-ColorOutput "Speed: $($adapter.LinkSpeed)" $colors.Info
        Write-ColorOutput "MAC Address: $($adapter.MacAddress)" $colors.Info
        Write-ColorOutput "Interface Description: $($adapter.InterfaceDescription)" $colors.Info
        
        # IP Configuration
        $ipConfig = Get-NetIPAddress -InterfaceIndex $adapter.InterfaceIndex -ErrorAction SilentlyContinue
        foreach ($ip in $ipConfig) {
            Write-ColorOutput "  IP Address: $($ip.IPAddress) ($($ip.AddressFamily))" $colors.Info
        }
        Write-ColorOutput ""
    }
    
    # Network Statistics
    Write-ColorOutput "--- Network Statistics ---" $colors.SubHeader
    $netStats = Get-NetAdapterStatistics
    foreach ($stat in $netStats) {
        if ($stat.BytesReceived -gt 0 -or $stat.BytesSent -gt 0) {
            Write-ColorOutput "$($stat.Name):" $colors.Info
            Write-ColorOutput "  Bytes Received: $([math]::Round($stat.BytesReceived / 1MB, 2)) MB" $colors.Info
            Write-ColorOutput "  Bytes Sent: $([math]::Round($stat.BytesSent / 1MB, 2)) MB" $colors.Info
            Write-ColorOutput ""
        }
    }
}

function Get-PerformanceInfo {
    Write-ColorOutput "=== PERFORMANCE INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # CPU Usage
    Write-ColorOutput "--- CPU Performance ---" $colors.SubHeader
    $cpuUsage = Get-WmiObject -Class Win32_Processor | Measure-Object -Property LoadPercentage -Average
    Write-ColorOutput "Average CPU Usage: $([math]::Round($cpuUsage.Average, 2))%" $colors.Info
    
    # Memory Performance
    Write-ColorOutput "--- Memory Performance ---" $colors.SubHeader
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $totalMemory = $os.TotalVisibleMemorySize * 1024
    $freeMemory = $os.FreePhysicalMemory * 1024
    $usedMemory = $totalMemory - $freeMemory
    Write-ColorOutput "Total Memory: $([math]::Round($totalMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Used Memory: $([math]::Round($usedMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Free Memory: $([math]::Round($freeMemory / 1GB, 2)) GB" $colors.Info
    Write-ColorOutput "Memory Usage: $([math]::Round(($usedMemory / $totalMemory) * 100, 2))%" $colors.Info
    
    # Page File
    Write-ColorOutput "--- Page File ---" $colors.SubHeader
    $pageFile = Get-WmiObject -Class Win32_PageFileUsage
    foreach ($pf in $pageFile) {
        Write-ColorOutput "Page File: $($pf.Name)" $colors.Info
        Write-ColorOutput "Size: $($pf.AllocatedBaseSize) MB" $colors.Info
        Write-ColorOutput "Used: $($pf.CurrentUsage) MB" $colors.Info
        Write-ColorOutput "Peak Usage: $($pf.PeakUsage) MB" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-SecurityInfo {
    Write-ColorOutput "=== SECURITY INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # Windows Defender
    Write-ColorOutput "--- Windows Defender ---" $colors.SubHeader
    try {
        $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($defender) {
            Write-ColorOutput "Real-time Protection: $($defender.RealTimeProtectionEnabled)" $colors.Info
            Write-ColorOutput "Antivirus Enabled: $($defender.AntivirusEnabled)" $colors.Info
            Write-ColorOutput "Last Quick Scan: $($defender.QuickScanStartTime)" $colors.Info
            Write-ColorOutput "Last Full Scan: $($defender.FullScanStartTime)" $colors.Info
        }
    } catch {
        Write-ColorOutput "Windows Defender information not available" $colors.Warning
    }
    
    # Firewall Status
    Write-ColorOutput "--- Firewall Status ---" $colors.SubHeader
    try {
        $firewall = Get-NetFirewallProfile
        foreach ($profile in $firewall) {
            Write-ColorOutput "$($profile.Name) Profile: $($profile.Enabled)" $colors.Info
        }
    } catch {
        Write-ColorOutput "Firewall information not available" $colors.Warning
    }
    
    # User Account Control
    Write-ColorOutput "--- User Account Control ---" $colors.SubHeader
    $uac = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction SilentlyContinue
    if ($uac) {
        Write-ColorOutput "UAC Enabled: $($uac.EnableLUA -eq 1)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-ServicesInfo {
    Write-ColorOutput "=== SERVICES INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $services = Get-Service | Group-Object Status
    foreach ($group in $services) {
        Write-ColorOutput "$($group.Name) Services: $($group.Count)" $colors.Info
    }
    
    Write-ColorOutput "\n--- Critical Services Status ---" $colors.SubHeader
    $criticalServices = @("Winmgmt", "Spooler", "Themes", "AudioSrv", "Dhcp", "Dnscache", "EventLog", "PlugPlay", "RpcSs", "Workstation")
    foreach ($service in $criticalServices) {
        $svc = Get-Service -Name $service -ErrorAction SilentlyContinue
        if ($svc) {
            $color = if ($svc.Status -eq "Running") { $colors.Success } else { $colors.Warning }
            Write-ColorOutput "$($svc.DisplayName): $($svc.Status)" $color
        }
    }
    Write-ColorOutput ""
}

function Get-ProcessesInfo {
    Write-ColorOutput "=== PROCESSES INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $processes = Get-Process | Sort-Object CPU -Descending
    Write-ColorOutput "Total Processes: $($processes.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Top 10 CPU Consumers ---" $colors.SubHeader
    $processes | Select-Object -First 10 | ForEach-Object {
        Write-ColorOutput "$($_.ProcessName) (PID: $($_.Id)): CPU: $([math]::Round($_.CPU, 2))s, Memory: $([math]::Round($_.WorkingSet / 1MB, 2)) MB" $colors.Info
    }
    
    Write-ColorOutput "\n--- Top 10 Memory Consumers ---" $colors.SubHeader
    $processes | Sort-Object WorkingSet -Descending | Select-Object -First 10 | ForEach-Object {
        Write-ColorOutput "$($_.ProcessName) (PID: $($_.Id)): Memory: $([math]::Round($_.WorkingSet / 1MB, 2)) MB, CPU: $([math]::Round($_.CPU, 2))s" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-UpdatesInfo {
    Write-ColorOutput "=== WINDOWS UPDATES INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    try {
        $session = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $updates = $searcher.Search("IsInstalled=0")
        
        Write-ColorOutput "Available Updates: $($updates.Updates.Count)" $colors.Info
        
        if ($updates.Updates.Count -gt 0) {
            Write-ColorOutput "\n--- Pending Updates ---" $colors.SubHeader
            foreach ($update in $updates.Updates) {
                Write-ColorOutput "$($update.Title)" $colors.Info
            }
        }
    } catch {
        Write-ColorOutput "Unable to check Windows Updates" $colors.Warning
    }
    Write-ColorOutput ""
}

function Get-UsersAndGroups {
    Write-ColorOutput "=== USERS AND GROUPS ===" $colors.Header
    Write-ColorOutput ""
    $users = Get-LocalUser | Select-Object Name, Enabled, Description
    Write-ColorOutput "--- Local Users ---" $colors.SubHeader
    foreach ($user in $users) {
        Write-ColorOutput "Name: $($user.Name) - Enabled: $($user.Enabled) - $($user.Description)" $colors.Info
    }

    $groups = Get-LocalGroup | Select-Object Name, Description
    Write-ColorOutput ""
    Write-ColorOutput "--- Local Groups ---" $colors.SubHeader
    foreach ($group in $groups) {
        Write-ColorOutput "Group: $($group.Name) - $($group.Description)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-ActiveNetworkConnections {
    Write-ColorOutput "=== ACTIVE NETWORK CONNECTIONS ===" $colors.Header
    Write-ColorOutput ""
    $netConnections = Get-NetTCPConnection | Where-Object {$_.State -eq "Established"}
    foreach ($connection in $netConnections) {
        Write-ColorOutput "Local: $($connection.LocalAddress):$($connection.LocalPort) ⇆ Remote: $($connection.RemoteAddress):$($connection.RemotePort) State: $($connection.State)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-EnvironmentInfo {
    Write-ColorOutput "=== ENVIRONMENT VARIABLES ===" $colors.Header
    Write-ColorOutput ""
    $envVars = Get-ChildItem Env: | Sort-Object Name
    foreach ($env in $envVars) {
        Write-ColorOutput "$($env.Name): $($env.Value)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-RegistryInfo {
    Write-ColorOutput "=== REGISTRY INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    # Windows Version from Registry
    Write-ColorOutput "--- Windows Version Info ---" $colors.SubHeader
    $winVersion = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    Write-ColorOutput "Product Name: $($winVersion.ProductName)" $colors.Info
    Write-ColorOutput "Release ID: $($winVersion.ReleaseId)" $colors.Info
    Write-ColorOutput "Current Build: $($winVersion.CurrentBuild)" $colors.Info
    Write-ColorOutput "UBR: $($winVersion.UBR)" $colors.Info
    Write-ColorOutput "Edition ID: $($winVersion.EditionID)" $colors.Info
    Write-ColorOutput ""
    
    # System Policies
    Write-ColorOutput "--- System Policies ---" $colors.SubHeader
    $policies = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -ErrorAction SilentlyContinue
    if ($policies) {
        Write-ColorOutput "EnableLUA: $($policies.EnableLUA)" $colors.Info
        Write-ColorOutput "ConsentPromptBehaviorAdmin: $($policies.ConsentPromptBehaviorAdmin)" $colors.Info
        Write-ColorOutput "ConsentPromptBehaviorUser: $($policies.ConsentPromptBehaviorUser)" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-CertificatesInfo {
    Write-ColorOutput "=== CERTIFICATES INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $certs = Get-ChildItem -Path Cert:\LocalMachine\My
    Write-ColorOutput "Personal Certificates: $($certs.Count)" $colors.Info
    
    $rootCerts = Get-ChildItem -Path Cert:\LocalMachine\Root
    Write-ColorOutput "Root Certificates: $($rootCerts.Count)" $colors.Info
    
    $intermediateCerts = Get-ChildItem -Path Cert:\LocalMachine\CA
    Write-ColorOutput "Intermediate Certificates: $($intermediateCerts.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Personal Certificates ---" $colors.SubHeader
    foreach ($cert in $certs | Select-Object -First 5) {
        Write-ColorOutput "Subject: $($cert.Subject)" $colors.Info
        Write-ColorOutput "Issuer: $($cert.Issuer)" $colors.Info
        Write-ColorOutput "Expires: $($cert.NotAfter)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-EventLogsInfo {
    Write-ColorOutput "=== EVENT LOGS INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $logs = Get-WinEvent -ListLog * | Where-Object {$_.RecordCount -gt 0} | Sort-Object RecordCount -Descending
    Write-ColorOutput "Total Event Logs: $($logs.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Top 10 Event Logs by Record Count ---" $colors.SubHeader
    $logs | Select-Object -First 10 | ForEach-Object {
        Write-ColorOutput "$($_.LogName): $($_.RecordCount) records" $colors.Info
    }
    
    # Recent System Events
    Write-ColorOutput "\n--- Recent System Events (Last 24 hours) ---" $colors.SubHeader
    $systemEvents = Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=(Get-Date).AddDays(-1)} -MaxEvents 5 -ErrorAction SilentlyContinue
    if ($systemEvents) {
        foreach ($event in $systemEvents) {
            Write-ColorOutput "$($event.TimeCreated): $($event.LevelDisplayName) - $($event.Id) - $($event.Message.Substring(0, [Math]::Min($event.Message.Length, 100)))..." $colors.Info
        }
    }
    Write-ColorOutput ""
}

function Get-StartupPrograms {
    Write-ColorOutput "=== STARTUP PROGRAMS ===" $colors.Header
    Write-ColorOutput ""
    
    # Registry startup locations
    $startupLocations = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"
    )
    
    foreach ($location in $startupLocations) {
        $items = Get-ItemProperty $location -ErrorAction SilentlyContinue
        if ($items) {
            Write-ColorOutput "--- $location ---" $colors.SubHeader
            $items.PSObject.Properties | Where-Object {$_.Name -notmatch '^PS'} | ForEach-Object {
                Write-ColorOutput "$($_.Name): $($_.Value)" $colors.Info
            }
            Write-ColorOutput ""
        }
    }
    
    # Startup folder
    $startupFolder = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
    $startupItems = Get-ChildItem $startupFolder -ErrorAction SilentlyContinue
    if ($startupItems) {
        Write-ColorOutput "--- Startup Folder ---" $colors.SubHeader
        foreach ($item in $startupItems) {
            Write-ColorOutput "$($item.Name)" $colors.Info
        }
    }
    Write-ColorOutput ""
}

function Get-InstalledPrograms {
    Write-ColorOutput "=== INSTALLED PROGRAMS ===" $colors.Header
    Write-ColorOutput ""
    
    $programs = Get-WmiObject -Class Win32_Product | Sort-Object Name
    Write-ColorOutput "Total Installed Programs: $($programs.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Recently Installed Programs ---" $colors.SubHeader
    $recentPrograms = $programs | Where-Object {$_.InstallDate -gt (Get-Date).AddDays(-30).ToString('yyyyMMdd')} | Sort-Object InstallDate -Descending
    foreach ($program in $recentPrograms | Select-Object -First 10) {
        Write-ColorOutput "$($program.Name) - Version: $($program.Version) - Installed: $($program.InstallDate)" $colors.Info
    }
    
    Write-ColorOutput "\n--- Largest Programs by Size ---" $colors.SubHeader
    $largestPrograms = $programs | Where-Object {$_.Size -gt 0} | Sort-Object Size -Descending | Select-Object -First 10
    foreach ($program in $largestPrograms) {
        $sizeGB = [math]::Round($program.Size / 1GB, 2)
        Write-ColorOutput "$($program.Name): $sizeGB GB" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-FontsInfo {
    Write-ColorOutput "=== FONTS INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $fontsPath = "$env:WINDIR\Fonts"
    $fonts = Get-ChildItem $fontsPath -Include *.ttf, *.otf, *.fon -Recurse
    Write-ColorOutput "Total Fonts: $($fonts.Count)" $colors.Info
    
    $fontTypes = $fonts | Group-Object Extension
    Write-ColorOutput "\n--- Font Types ---" $colors.SubHeader
    foreach ($type in $fontTypes) {
        Write-ColorOutput "$($type.Name): $($type.Count) fonts" $colors.Info
    }
    Write-ColorOutput ""
}

function Get-PrintersInfo {
    Write-ColorOutput "=== PRINTERS INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $printers = Get-WmiObject -Class Win32_Printer
    Write-ColorOutput "Total Printers: $($printers.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Printer Details ---" $colors.SubHeader
    foreach ($printer in $printers) {
        Write-ColorOutput "Name: $($printer.Name)" $colors.Info
        Write-ColorOutput "Status: $($printer.PrinterStatus)" $colors.Info
        Write-ColorOutput "Location: $($printer.Location)" $colors.Info
        Write-ColorOutput "Driver: $($printer.DriverName)" $colors.Info
        Write-ColorOutput "Default: $($printer.Default)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-USBInfo {
    Write-ColorOutput "=== USB DEVICES INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $usbDevices = Get-WmiObject -Class Win32_USBControllerDevice | ForEach-Object {[wmi]($_.Dependent)}
    Write-ColorOutput "Total USB Devices: $($usbDevices.Count)" $colors.Info
    
    Write-ColorOutput "\n--- USB Device Details ---" $colors.SubHeader
    foreach ($device in $usbDevices | Select-Object -First 10) {
        Write-ColorOutput "Device: $($device.Caption)" $colors.Info
        Write-ColorOutput "Manufacturer: $($device.Manufacturer)" $colors.Info
        Write-ColorOutput "Status: $($device.Status)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-AudioInfo {
    Write-ColorOutput "=== AUDIO INFORMATION ===" $colors.Header
    Write-ColorOutput ""
    
    $audioDevices = Get-WmiObject -Class Win32_SoundDevice
    Write-ColorOutput "Total Audio Devices: $($audioDevices.Count)" $colors.Info
    
    Write-ColorOutput "\n--- Audio Device Details ---" $colors.SubHeader
    foreach ($device in $audioDevices) {
        Write-ColorOutput "Device: $($device.Caption)" $colors.Info
        Write-ColorOutput "Manufacturer: $($device.Manufacturer)" $colors.Info
        Write-ColorOutput "Status: $($device.Status)" $colors.Info
        Write-ColorOutput ""
    }
}

function Get-SystemInfo {
    param(
        [bool]$Detailed = $false,
        [bool]$Performance = $false,
        [bool]$Security = $false,
        [bool]$Services = $false,
        [bool]$Processes = $false,
        [bool]$Updates = $false,
        [bool]$Hardware = $false,
        [bool]$Network = $false,
        [bool]$Users = $false,
        [bool]$Connections = $false,
        [bool]$CPUTimes = $false,
        [bool]$MemoryDetailed = $false,
        [bool]$Environment = $false,
        [bool]$Registry = $false,
        [bool]$Certificates = $false,
        [bool]$EventLogs = $false,
        [bool]$StartupPrograms = $false,
        [bool]$InstalledPrograms = $false,
        [bool]$Fonts = $false,
        [bool]$Printers = $false,
        [bool]$USB = $false,
        [bool]$Audio = $false,
        [bool]$All = $false
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-ColorOutput "Enhanced System Information Report - Generated: $timestamp" $colors.Header
    Write-ColorOutput ("=" * 80) $colors.Header
    Write-ColorOutput ""
    
    # Always show system overview
    Get-SystemOverview
    
    if ($All -or $Hardware -or $Detailed) {
        Get-HardwareInfo
        Get-StorageInfo
    }
    
    if ($All -or $Network -or $Detailed) {
        Get-NetworkInfo
    }
    
    if ($All -or $Performance) {
        Get-PerformanceInfo
    }
    
    if ($All -or $Security) {
        Get-SecurityInfo
    }
    
    if ($All -or $Services) {
        Get-ServicesInfo
    }
    
    if ($All -or $Processes) {
        Get-ProcessesInfo
    }
    
    if ($All -or $Updates) {
        Get-UpdatesInfo
    }
    
    if ($All -or $Users) {
        Get-UsersAndGroups
    }
    
    if ($All -or $Connections) {
        Get-ActiveNetworkConnections
    }
    
    if ($All -or $CPUTimes) {
        Get-AdvancedCPUTimes
    }
    
    if ($All -or $MemoryDetailed) {
        Get-AdvancedMemoryDetails
    }
    
    if ($All -or $Environment) {
        Get-EnvironmentInfo
    }
    
    if ($All -or $Registry) {
        Get-RegistryInfo
    }
    
    if ($All -or $Certificates) {
        Get-CertificatesInfo
    }
    
    if ($All -or $EventLogs) {
        Get-EventLogsInfo
    }
    
    if ($All -or $StartupPrograms) {
        Get-StartupPrograms
    }
    
    if ($All -or $InstalledPrograms) {
        Get-InstalledPrograms
    }
    
    if ($All -or $Fonts) {
        Get-FontsInfo
    }
    
    if ($All -or $Printers) {
        Get-PrintersInfo
    }
    
    if ($All -or $USB) {
        Get-USBInfo
    }
    
    if ($All -or $Audio) {
        Get-AudioInfo
    }
    
    Write-ColorOutput ("=" * 80) $colors.Header
    Write-ColorOutput "Report completed at: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" $colors.Header
}

# Main execution
try {
    if ($args -contains "-help" -or $args -contains "--help" -or $args -contains "-h") {
        Write-ColorOutput @"
Enhanced System Information Tool

Usage: .\system-info.ps1 [options]

Basic Parameters:
  -Detailed         : Show detailed system information (hardware, storage, network)
  -Performance      : Show performance and resource usage information
  -Security         : Show security-related information (Defender, Firewall, UAC)
  -Services         : Show services status information
  -Processes        : Show running processes information
  -Updates          : Show Windows updates information
  -Hardware         : Show hardware information only
  -Network          : Show network information only
  -All              : Show all available information

Advanced Parameters:
  -Users            : Show local users and groups information
  -Connections      : Show active network connections
  -CPUTimes         : Show advanced CPU timing information
  -MemoryDetailed   : Show detailed memory information
  -Environment      : Show environment variables
  -Registry         : Show registry information
  -Certificates     : Show certificate information
  -EventLogs        : Show event logs information
  -StartupPrograms  : Show startup programs
  -InstalledPrograms: Show installed programs
  -Fonts            : Show fonts information
  -Printers         : Show printers information
  -USB              : Show USB devices information
  -Audio            : Show audio devices information

Output Parameters:
  -Export           : Export results to a file
  -OutputPath       : Specify output file path (default: auto-generated with timestamp)
  -Format           : Output format (Console, JSON, CSV, HTML) [Future feature]

Examples:
  .\system-info.ps1                    # Basic system overview
  .\system-info.ps1 -Detailed          # Detailed system information
  .\system-info.ps1 -All               # Complete system report
  .\system-info.ps1 -Hardware          # Hardware information only
  .\system-info.ps1 -Performance       # Performance metrics only
  .\system-info.ps1 -Security          # Security status only
  .\system-info.ps1 -Users -Groups     # User and group information
  .\system-info.ps1 -Registry -Environment # Registry and environment info
  .\system-info.ps1 -All -Export       # Complete report exported to file
  .\system-info.ps1 -Processes -Services # Processes and services info
"@ $colors.Info
        return
    }
    
    # Capture output for export if needed
    if ($Export) {
        Start-Transcript -Path $OutputPath -Force
    }
    
    Get-SystemInfo -Detailed $Detailed -Performance $Performance -Security $Security -Services $Services -Processes $Processes -Updates $Updates -Hardware $Hardware -Network $Network -Users $Users -Connections $Connections -CPUTimes $CPUTimes -MemoryDetailed $MemoryDetailed -Environment $Environment -Registry $Registry -Certificates $Certificates -EventLogs $EventLogs -StartupPrograms $StartupPrograms -InstalledPrograms $InstalledPrograms -Fonts $Fonts -Printers $Printers -USB $USB -Audio $Audio -All $All
    
    if ($Export) {
        Stop-Transcript
        Write-ColorOutput "\nSystem information exported to: $OutputPath" $colors.Success
    }
    
}
catch {
    Write-ColorOutput "Error getting system information: $($_.Exception.Message)" $colors.Warning
    if ($Export -and (Get-Command Stop-Transcript -ErrorAction SilentlyContinue)) {
        Stop-Transcript -ErrorAction SilentlyContinue
    }
}
