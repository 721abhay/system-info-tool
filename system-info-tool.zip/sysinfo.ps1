# System Information Tool Launcher
# This script provides a convenient way to launch the comprehensive system information tool

param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Arguments
)

# Get the directory where this launcher script is located
$LauncherDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $LauncherDir "utilities\system-info.ps1"

# Check if the main script exists
if (-not (Test-Path $ScriptPath)) {
    Write-Host "Error: System information script not found at $ScriptPath" -ForegroundColor Red
    exit 1
}

# Execute the main script with all passed arguments
try {
    & $ScriptPath @Arguments
} catch {
    Write-Host "Error executing system information tool: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
